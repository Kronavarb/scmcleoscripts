set word wrap to ON to read this file properly.

this program should not be distributed anywhere else than www.gtatools.com or other gtanet sites such as www.gtagarage.com. if you distribute this program on any other website your server shall crash, please read the informations about distribution on www.gtatools.com.

Delfi's ASI loader for san andreas 1.0 (260605)
copyright 2005 Jernej L.

Copyright 2005 Delfi - Jernej L. 
email: jernejcoder@gmail.com or jernej@gtatools.com

installation: extract both dlls into san andreas folder overwriting vorbisfile.dll that came with the game.

this package enabled developers to develop "asi-style" plugins for san andreas like we were able to do with gta3 and vice-city's MSS sound system plugin system.
 
any asi files in gta-sa folder will be loaded on startup, that is immediately when program loads.
 
asi files are simply dll files with asi extension, you can use them to hook code in gta-sa executable etc..
 
this asi loader is better than d3d9.dll variant because it doesn't cause graphical glitches and doesn't interfere with directx, so you can use spedometer mod and asi plugins at the same time.